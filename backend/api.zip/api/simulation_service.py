"""
SUMO-based traffic simulation with NetworkX fallback.

Runs headless SUMO on the pre-built Bangalore network in auto_tool/, using
demand-scaled routes derived from Phase 1 (Uber Movement) when possible.
"""

from __future__ import annotations

import json
import logging
import re
import shutil
import subprocess
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

PROJECT_ROOT = Path(__file__).resolve().parents[2]
AUTO_TOOL_DIR = PROJECT_ROOT / "auto_tool"
BASELINE_NET = AUTO_TOOL_DIR / "cleaned_network.net.xml"
BASELINE_ROU = AUTO_TOOL_DIR / "simulation.rou.xml"
PHASE1_DIR = Path(__file__).resolve().parents[1] / "phases" / "phase1_demand"
UBER_CSV = PHASE1_DIR / "bangalore-wards-2019-3-OnlyWeekdays-HourlyAggregate.csv"
WARDS_GEOJSON = PHASE1_DIR / "bangalore_wards.json"

HOURLY_LABELS = [
    "6 AM", "7 AM", "8 AM", "9 AM", "10 AM", "11 AM",
    "12 PM", "5 PM", "6 PM", "7 PM",
]
HOURLY_FACTORS = [0.45, 0.72, 0.92, 1.0, 0.78, 0.55, 0.58, 0.88, 0.96, 0.8]

SIMULATION_SECONDS = 3600
REFERENCE_TRIP_VOLUME = 390.0
MIN_TARGET_VEHICLES = 100
MAX_TARGET_VEHICLES = 6000
MIN_UBER_ROUTE_SUCCESS_RATE = 0.5


def _arrival_rate_from_demand(demand_data: dict) -> float:
    matrix = demand_data.get("demand_matrix", [])
    total_trips = sum(float(row.get("synthetic_trip_count", 0)) for row in matrix)
    return max(2.0, min(12.0, total_trips / 4.0))


def _build_hourly_traffic(demand_data: dict, improvement_ratio: float) -> list:
    matrix = demand_data.get("demand_matrix", [])
    peak_volume = sum(float(row.get("synthetic_trip_count", 0)) for row in matrix)
    base_peak = max(12, int(peak_volume * 8))
    improvement_ratio = max(0.0, min(0.65, improvement_ratio))

    return [
        {
            "time": label,
            "before": int(base_peak * factor),
            "after": int(base_peak * factor * (1 - improvement_ratio)),
        }
        for label, factor in zip(HOURLY_LABELS, HOURLY_FACTORS)
    ]


def _total_trip_count(demand_data: dict) -> float:
    matrix = demand_data.get("demand_matrix", [])
    return sum(float(row.get("synthetic_trip_count", 0)) for row in matrix)


def _target_vehicle_count(demand_data: dict) -> int:
    total_trips = _total_trip_count(demand_data)
    baseline_count = _baseline_vehicle_count()
    if total_trips <= 0:
        return baseline_count
    scaled = round(baseline_count * total_trips / REFERENCE_TRIP_VOLUME)
    return max(MIN_TARGET_VEHICLES, min(MAX_TARGET_VEHICLES, scaled))


def _baseline_vehicle_count() -> int:
    if not BASELINE_ROU.exists():
        return MAX_TARGET_VEHICLES
    text = BASELINE_ROU.read_text(encoding="utf-8", errors="ignore")
    count = len(re.findall(r"<vehicle\b", text))
    return count or MAX_TARGET_VEHICLES


def _sumo_binary() -> Optional[str]:
    return shutil.which("sumo-gui")


def _geojson_centroid(geometry: dict) -> Optional[tuple[float, float]]:
    geom_type = geometry.get("type")
    coordinates = geometry.get("coordinates")
    if not coordinates:
        return None

    if geom_type == "Polygon":
        ring = coordinates[0]
    elif geom_type == "MultiPolygon":
        ring = coordinates[0][0]
    else:
        return None

    if not ring:
        return None
    lon = sum(point[0] for point in ring) / len(ring)
    lat = sum(point[1] for point in ring) / len(ring)
    return lon, lat


def _load_ward_centroids() -> dict[str, tuple[float, float]]:
    if not WARDS_GEOJSON.exists():
        return {}

    with open(WARDS_GEOJSON, encoding="utf-8") as file:
        payload = json.load(file)

    centroids: dict[str, tuple[float, float]] = {}
    for feature in payload.get("features", []):
        movement_id = feature.get("properties", {}).get("MOVEMENT_ID")
        if movement_id is None:
            continue
        centroid = _geojson_centroid(feature.get("geometry", {}))
        if centroid:
            centroids[str(movement_id)] = centroid
    return centroids


def _load_demand_rows_from_uber_csv(demand_data: dict) -> list[dict]:
    """Supplement demand_matrix with Uber Movement CSV rows when available."""
    if not UBER_CSV.exists():
        return []

    try:
        import pandas as pd
    except ImportError:
        return []

    scenario = demand_data.get("scenario_metadata", {})
    target_hour = int(scenario.get("target_hour", 9))
    movement_id = scenario.get("movement_id")

    try:
        frame = pd.read_csv(UBER_CSV)
    except Exception:
        return []

    if "hod" not in frame.columns:
        return []

    frame = frame[frame["hod"] == target_hour]
    if movement_id is not None:
        movement_id = int(movement_id)
        frame = frame[(frame["sourceid"] == movement_id) | (frame["dstid"] == movement_id)]

    rows = []
    for _, row in frame.head(50).iterrows():
        travel_sec = float(row.get("mean_travel_time", 0) or 0)
        travel_min = max(0.5, travel_sec / 60.0)
        rows.append(
            {
                "sourceid": int(row["sourceid"]),
                "dstid": int(row["dstid"]),
                "synthetic_trip_count": max(1.0, 100.0 / travel_min),
                "travel_time_min": round(travel_min, 2),
            }
        )
    return rows


def _demand_rows_for_routes(demand_data: dict) -> list[dict]:
    matrix = list(demand_data.get("demand_matrix", []) or [])
    if matrix:
        return matrix

    uber_rows = _load_demand_rows_from_uber_csv(demand_data)
    return uber_rows


def _nearest_edge(net, lon: float, lat: float, radius: float):
    x, y = net.convertLonLat2XY(lon, lat)
    neighbors = net.getNeighboringEdges(x, y, radius)
    if not neighbors:
        return None
    return neighbors[0][0]


def _route_edges_for_od(net, centroids: dict[str, tuple[float, float]], source_id, dest_id):
    source = centroids.get(str(source_id))
    dest = centroids.get(str(dest_id))
    if not source or not dest:
        return None

    from_edge = None
    to_edge = None
    for radius in (500, 1200, 2500):
        from_edge = _nearest_edge(net, source[0], source[1], radius)
        to_edge = _nearest_edge(net, dest[0], dest[1], radius)
        if from_edge and to_edge:
            break

    if not from_edge or not to_edge or from_edge.getID() == to_edge.getID():
        return None

    path, _ = net.getShortestPath(from_edge, to_edge)
    if not path:
        return None

    edge_ids = [edge.getID() for edge in path if not edge.getID().startswith(":")]
    if len(edge_ids) < 2:
        return None
    return edge_ids


def _write_route_file(output_path: Path, routes: list[tuple[float, list[str]]]) -> None:
    root = ET.Element("routes")
    ET.SubElement(
        root,
        "vType",
        {
            "id": "car",
            "accel": "2.6",
            "decel": "4.5",
            "sigma": "0.5",
            "length": "5.0",
            "maxSpeed": "50.0",
        },
    )

    for index, (depart, edge_ids) in enumerate(routes):
        vehicle = ET.SubElement(
            root,
            "vehicle",
            {
                "id": f"demand_vehicle_{index}",
                "type": "car",
                "depart": f"{depart:.2f}",
            },
        )
        ET.SubElement(vehicle, "route", {"edges": " ".join(edge_ids)})

    ET.ElementTree(root).write(output_path, encoding="utf-8", xml_declaration=True)


def _try_build_uber_demand_routes(
    net_path: Path,
    demand_data: dict,
    target_vehicles: int,
    simulation_time: int,
) -> Optional[Path]:
    """Build a demand-scaled .rou.xml from Uber Movement OD mapped onto the SUMO network."""
    if not net_path.exists() or not WARDS_GEOJSON.exists():
        return None

    demand_rows = _demand_rows_for_routes(demand_data)
    if not demand_rows:
        return None

    try:
        from sumolib.net import readNet
    except ImportError:
        try:
            import sumolib

            readNet = sumolib.net.readNet
        except ImportError:
            return None

    try:
        import pyproj  # noqa: F401 — required by sumolib geo conversion
    except ImportError:
        return None

    try:
        net = readNet(str(net_path), withInternal=False)
    except Exception:
        return None

    try:
        centroids = _load_ward_centroids()
        if not centroids:
            return None

        weighted_routes: list[tuple[float, list[str]]] = []
        total_weight = sum(float(row.get("synthetic_trip_count", 0) or 0) for row in demand_rows)
        if total_weight <= 0:
            return None

        for row in demand_rows:
            edge_ids = _route_edges_for_od(
                net,
                centroids,
                row.get("sourceid"),
                row.get("dstid"),
            )
            if not edge_ids:
                continue
            weight = float(row.get("synthetic_trip_count", 0) or 0)
            count = max(1, round(target_vehicles * weight / total_weight))
            weighted_routes.extend([(0.0, edge_ids)] * count)

        if not weighted_routes:
            return None

        if len(weighted_routes) > target_vehicles:
            stride = len(weighted_routes) / target_vehicles
            weighted_routes = [weighted_routes[int(i * stride)] for i in range(target_vehicles)]
        elif len(weighted_routes) < target_vehicles:
            extra = target_vehicles - len(weighted_routes)
            for i in range(extra):
                weighted_routes.append(weighted_routes[i % len(weighted_routes)])

        step = simulation_time / max(1, len(weighted_routes) - 1) if len(weighted_routes) > 1 else simulation_time
        scheduled = [(round(i * step, 2), edges) for i, (_, edges) in enumerate(weighted_routes)]

        temp_dir = Path(tempfile.mkdtemp(prefix="uidt_sumo_routes_"))
        route_path = temp_dir / "demand.rou.xml"
        _write_route_file(route_path, scheduled)

        success_rate = len(scheduled) / max(1, target_vehicles)
        if success_rate < MIN_UBER_ROUTE_SUCCESS_RATE:
            shutil.rmtree(temp_dir, ignore_errors=True)
            return None

        return route_path
    except Exception:
        return None


def _scale_baseline_routes(
    source_rou: Path,
    target_vehicles: int,
    simulation_time: int,
    output_path: Path,
) -> None:
    tree = ET.parse(source_rou)
    root = tree.getroot()

    vtype = root.find("vType")
    vehicles = root.findall("vehicle")
    if not vehicles:
        raise ValueError("Baseline route file contains no vehicles.")

    if len(vehicles) >= target_vehicles:
        indices = [
            int(i * (len(vehicles) - 1) / max(1, target_vehicles - 1))
            for i in range(target_vehicles)
        ]
        selected = [vehicles[index] for index in indices]
    else:
        selected = []
        for i in range(target_vehicles):
            selected.append(vehicles[i % len(vehicles)])

    new_root = ET.Element("routes")
    if vtype is not None:
        new_root.append(ET.Element("vType", vtype.attrib))

    step = simulation_time / max(1, len(selected) - 1) if len(selected) > 1 else 0.0
    for index, vehicle in enumerate(selected):
        attrs = dict(vehicle.attrib)
        attrs["id"] = f"scaled_vehicle_{index}"
        attrs["depart"] = f"{index * step:.2f}"
        new_vehicle = ET.SubElement(new_root, "vehicle", attrs)
        route = vehicle.find("route")
        if route is not None:
            ET.SubElement(new_vehicle, "route", dict(route.attrib))

    ET.ElementTree(new_root).write(output_path, encoding="utf-8", xml_declaration=True)


def _prepare_route_file(
    net_path: Path,
    demand_data: dict,
    target_vehicles: int,
    simulation_time: int,
    temp_dir: Path,
) -> Path:
    uber_route = _try_build_uber_demand_routes(
        net_path, demand_data, target_vehicles, simulation_time
    )
    if uber_route is not None:
        return uber_route

    scaled_path = temp_dir / "scaled.rou.xml"
    _scale_baseline_routes(BASELINE_ROU, target_vehicles, simulation_time, scaled_path)
    return scaled_path


def _run_sumo(
    net_path: Path,
    route_path: Path,
    simulation_time: int,
    tripinfo_path: Path,
    summary_path: Path,
) -> None:
    sumo = _sumo_binary()
    if not sumo:
        raise FileNotFoundError("SUMO binary 'sumo' not found on PATH")

    command = [
        sumo,
        "-n",
        str(net_path),
        "-r",
        str(route_path),
        "--begin",
        "0",
        "--end",
        str(simulation_time),
        "--no-warnings",
        "--no-step-log",
        "--ignore-route-errors",
        "true",
        "--collision.action",
        "warn",
        f"--tripinfo-output={tripinfo_path}",
        f"--summary-output={summary_path}",
        "--tripinfo-output.write-unfinished",
        "true",
        "--start",
        "--quit-on-end",
        "--delay",
        "10",
    ]

    result = subprocess.run(
        command,
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        stderr = (result.stderr or result.stdout or "").strip()
        raise RuntimeError(stderr or f"SUMO exited with code {result.returncode}")


def _parse_tripinfo(tripinfo_path: Path) -> dict:
    if not tripinfo_path.exists():
        return {
            "throughput": 0,
            "avg_travel_time_sec": 0.0,
            "active_vehicles": 0,
            "avg_congestion_ratio": 0.0,
        }

    root = ET.parse(tripinfo_path).getroot()
    trips = list(root)
    durations = []
    waiting_times = []

    for trip in trips:
        duration = float(trip.get("duration", 0) or 0)
        waiting = float(trip.get("waitingTime", 0) or 0)
        if duration > 0:
            durations.append(duration)
            waiting_times.append(waiting)

    throughput = len(durations)
    avg_travel = sum(durations) / throughput if throughput else 0.0
    avg_waiting = sum(waiting_times) / len(waiting_times) if waiting_times else 0.0
    congestion_ratio = (avg_waiting / avg_travel) if avg_travel > 0 else 0.0

    return {
        "throughput": throughput,
        "avg_travel_time_sec": round(avg_travel, 2),
        "active_vehicles": 0,
        "avg_congestion_ratio": round(min(1.0, congestion_ratio), 4),
    }


def _parse_summary(summary_path: Path) -> dict:
    if not summary_path.exists():
        return {"active_vehicles": 0, "avg_congestion_ratio": 0.0}

    root = ET.parse(summary_path).getroot()
    steps = list(root)
    if not steps:
        return {"active_vehicles": 0, "avg_congestion_ratio": 0.0}

    congestion_samples = []
    last_running = 0
    for step in steps:
        running = int(float(step.get("running", 0) or 0))
        waiting = int(float(step.get("waiting", 0) or 0))
        last_running = running
        if running > 0:
            congestion_samples.append(waiting / running)

    avg_congestion = (
        sum(congestion_samples) / len(congestion_samples) if congestion_samples else 0.0
    )
    return {
        "active_vehicles": last_running,
        "avg_congestion_ratio": round(min(1.0, avg_congestion), 4),
    }


def _merge_run_metrics(tripinfo_metrics: dict, summary_metrics: dict) -> dict:
    merged = dict(tripinfo_metrics)
    merged["active_vehicles"] = summary_metrics.get("active_vehicles", 0)
    if summary_metrics.get("avg_congestion_ratio", 0) > 0:
        merged["avg_congestion_ratio"] = summary_metrics["avg_congestion_ratio"]
    return merged


def _run_sumo_scenario(
    net_path: Path,
    route_path: Path,
    simulation_time: int,
    temp_dir: Path,
    label: str,
) -> dict:
    tripinfo_path = temp_dir / f"{label}_tripinfo.xml"
    summary_path = temp_dir / f"{label}_summary.xml"
    _run_sumo(net_path, route_path, simulation_time, tripinfo_path, summary_path)

    tripinfo_metrics = _parse_tripinfo(tripinfo_path)
    summary_metrics = _parse_summary(summary_path)
    metrics = _merge_run_metrics(tripinfo_metrics, summary_metrics)

    for path in (tripinfo_path, summary_path):
        try:
            path.unlink(missing_ok=True)
        except OSError:
            pass

    return metrics


def _resolve_after_net_path(modified_graph, is_feasible: bool) -> Path:
    """Placeholder: modified GraphML → .net.xml conversion is not implemented yet."""
    _ = (modified_graph, is_feasible)
    return BASELINE_NET


def _build_result_dict(
    before: dict,
    after: dict,
    demand_data: dict,
    arrival_rate: float,
    steps: int,
) -> dict:
    time_before = before["avg_travel_time_sec"]
    time_after = after["avg_travel_time_sec"]
    time_reduction_pct = 0.0
    if time_before > 0:
        time_reduction_pct = round(((time_before - time_after) / time_before) * 100, 1)

    congestion_before = before["avg_congestion_ratio"]
    congestion_after = after["avg_congestion_ratio"]
    congestion_reduction_pct = 0.0
    if congestion_before > 0:
        congestion_reduction_pct = round(
            ((congestion_before - congestion_after) / congestion_before) * 100, 1
        )

    improvement_ratio = max(time_reduction_pct, congestion_reduction_pct) / 100

    return {
        "status": "complete",
        "steps": steps,
        "arrival_rate": round(arrival_rate, 2),
        "before": before,
        "after": after,
        "avg_travel_time_before_sec": time_before,
        "avg_travel_time_after_sec": time_after,
        "avg_travel_time_before_min": round(time_before / 60, 2),
        "avg_travel_time_after_min": round(time_after / 60, 2),
        "time_reduction_pct": time_reduction_pct,
        "congestion_reduction_pct": congestion_reduction_pct,
        "hourly_traffic": _build_hourly_traffic(demand_data, improvement_ratio),
    }


def _run_sumo_simulation(
    demand_data: dict,
    modified_graph,
    is_feasible: bool,
    arrival_rate: float,
) -> dict:
    if not BASELINE_NET.exists() or not BASELINE_ROU.exists():
        raise FileNotFoundError("SUMO baseline network or route files are missing from auto_tool/")

    target_vehicles = _target_vehicle_count(demand_data)
    after_net = _resolve_after_net_path(modified_graph, is_feasible)

    temp_dir = Path(tempfile.mkdtemp(prefix="uidt_sumo_run_"))
    route_path: Optional[Path] = None
    uber_route_dir: Optional[Path] = None

    try:
        route_path = _prepare_route_file(
            BASELINE_NET,
            demand_data,
            target_vehicles,
            SIMULATION_SECONDS,
            temp_dir,
        )
        if route_path.parent.name.startswith("uidt_sumo_routes_"):
            uber_route_dir = route_path.parent

        before = _run_sumo_scenario(
            BASELINE_NET,
            route_path,
            SIMULATION_SECONDS,
            temp_dir,
            "before",
        )
        after = _run_sumo_scenario(
            after_net,
            route_path,
            SIMULATION_SECONDS,
            temp_dir,
            "after",
        )
    finally:
        if route_path and route_path.exists() and route_path.parent == temp_dir:
            route_path.unlink(missing_ok=True)
        if uber_route_dir and uber_route_dir.exists():
            shutil.rmtree(uber_route_dir, ignore_errors=True)
        shutil.rmtree(temp_dir, ignore_errors=True)

    return _build_result_dict(before, after, demand_data, arrival_rate, SIMULATION_SECONDS)


def _nearest_drivable_edge(net, lon: float, lat: float):
    x, y = net.convertLonLat2XY(lon, lat)
    for radius in (50, 150, 500, 1500):
        candidates = sorted(net.getNeighboringEdges(x, y, radius), key=lambda item: item[1])
        for edge, _distance in candidates:
            if not edge.getID().startswith(":") and edge.allows("passenger"):
                return edge
    raise ValueError("The selected point is not close to a drivable SUMO road.")


def _build_corridor_route_file(
    output_path: Path,
    origin: dict,
    destination: dict,
    selected_vehicle_count: int,
) -> None:
    try:
        from sumolib.net import readNet
    except ImportError as exc:
        raise RuntimeError("sumolib is required for map-to-SUMO routing.") from exc

    net = readNet(str(BASELINE_NET), withInternal=False)
    start_edge = _nearest_drivable_edge(net, float(origin["lon"]), float(origin["lat"]))
    end_edge = _nearest_drivable_edge(
        net, float(destination["lon"]), float(destination["lat"])
    )
    path, _cost = net.getShortestPath(start_edge, end_edge, vClass="passenger")
    if not path:
        raise ValueError("SUMO could not find a drivable route between the selected points.")

    tree = ET.parse(BASELINE_ROU)
    root = tree.getroot()
    edge_ids = " ".join(edge.getID() for edge in path if not edge.getID().startswith(":"))
    departure_window = min(1800.0, float(SIMULATION_SECONDS) / 2)
    for index in range(selected_vehicle_count):
        depart = index * departure_window / max(1, selected_vehicle_count - 1)
        vehicle = ET.SubElement(
            root,
            "vehicle",
            {
                "id": f"selected_od_{index}",
                "type": "car",
                "depart": f"{depart:.2f}",
                "departLane": "best",
            },
        )
        ET.SubElement(vehicle, "route", {"edges": edge_ids})
    tree.write(output_path, encoding="utf-8", xml_declaration=True)


def _parse_selected_tripinfo(tripinfo_path: Path, selected_vehicle_count: int) -> dict:
    trips = [
        trip
        for trip in ET.parse(tripinfo_path).getroot().findall("tripinfo")
        if (trip.get("id") or "").startswith("selected_od_")
    ]
    completed = [trip for trip in trips if float(trip.get("arrival", -1)) >= 0]
    durations = [float(trip.get("duration", 0) or 0) for trip in completed]
    wait_ratios = [
        float(trip.get("waitingTime", 0) or 0) / max(1.0, float(trip.get("duration", 0) or 0))
        for trip in trips
    ]
    return {
        "throughput": len(completed),
        "avg_travel_time_sec": round(sum(durations) / len(durations), 2) if durations else 0.0,
        "active_vehicles": max(0, selected_vehicle_count - len(completed)),
        "avg_congestion_ratio": round(sum(wait_ratios) / len(wait_ratios), 4) if wait_ratios else 0.0,
    }


def run_corridor_simulation(origin: dict, destination: dict, demand_data: dict) -> dict:
    """Run visible SUMO background traffic and report only the clicked OD corridor."""
    sumo = _sumo_binary()
    if not sumo:
        raise RuntimeError("sumo-gui was not found on PATH.")
    if not BASELINE_NET.exists() or not BASELINE_ROU.exists():
        raise FileNotFoundError("SUMO network or baseline route file is missing.")

    selected_vehicle_count = max(20, min(300, round(_total_trip_count(demand_data) / 2)))
    arrival_rate = _arrival_rate_from_demand(demand_data)
    with tempfile.TemporaryDirectory(prefix="uidt_corridor_") as directory:
        temp_dir = Path(directory)
        route_path = temp_dir / "corridor.rou.xml"
        tripinfo_path = temp_dir / "corridor_tripinfo.xml"
        summary_path = temp_dir / "corridor_summary.xml"
        _build_corridor_route_file(route_path, origin, destination, selected_vehicle_count)
        _run_sumo(
            BASELINE_NET,
            route_path,
            SIMULATION_SECONDS,
            tripinfo_path,
            summary_path,
        )
        metrics = _parse_selected_tripinfo(tripinfo_path, selected_vehicle_count)

    result = _build_result_dict(
        metrics, metrics, demand_data, arrival_rate, SIMULATION_SECONDS
    )
    result["selected_vehicle_count"] = selected_vehicle_count
    result["scope"] = "selected_origin_destination"
    return result


def run_traffic_simulation(original_graph, modified_graph, demand_data: dict, is_feasible: bool) -> dict:
    arrival_rate = _arrival_rate_from_demand(demand_data)

    return _run_sumo_simulation(
        demand_data=demand_data,
        modified_graph=modified_graph,
        is_feasible=is_feasible,
        arrival_rate=arrival_rate,
    )
