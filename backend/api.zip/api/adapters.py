"""Convert frontend wizard payloads to/from backend pipeline formats."""

from typing import Optional

from api.simulation_service import _build_hourly_traffic


def wizard_to_phase34_payload(request: dict) -> dict:
    route = request.get("route", {})
    start = route.get("start", {})
    end = route.get("end", {})
    intervention = request.get("intervention", {})
    scenario = request.get("scenario", {})
    options = request.get("options", {})

    coords = intervention.get("geometry", {}).get("coordinates")
    if not coords and start and end:
        coords = [
            [float(start["lon"]), float(start["lat"])],
            [float(end["lon"]), float(end["lat"])],
        ]

    mid_lat = (float(start.get("lat", 0)) + float(end.get("lat", 0))) / 2
    mid_lon = (float(start.get("lon", 0)) + float(end.get("lon", 0))) / 2

    infra_labels = {
        "flyover": "Flyover",
        "tunnel": "Tunnel",
        "road": "New Road",
    }
    infra_key = intervention.get("infra_type", "flyover")
    if intervention.get("type") == "optimize":
        infra_label = "Route Optimization"
    else:
        infra_label = infra_labels.get(infra_key, "New Road")

    road_width = float(intervention.get("road_width_m", 8))
    if options.get("widening"):
        road_width = min(24.0, road_width + 4.0)

    return {
        "scenario_metadata": {
            "name": request.get("report_name")
            or f"{start.get('name', 'Start')} to {end.get('name', 'End')}",
            "description": "Generated from UIDT Traffic Wizard",
        },
        "proposal": {
            "place_name": scenario.get("place_name", "Kathriguppe, Bangalore, India"),
            "point": [mid_lat, mid_lon],
            "dist_m": int(scenario.get("dist_m", 5000)),
            "infra_type": infra_label,
            "road_width_m": road_width,
            "is_oneway": bool(intervention.get("is_oneway", False)),
            "geometry_type": intervention.get("geometry", {}).get("type", "LineString"),
            "smart_analysis": bool(options.get("smart_analysis", True)),
            "coordinates": coords or [],
        },
    }


def build_analyze_response(
    request: dict,
    phase34_output: dict,
    demand_data: dict,
    phase2_result: dict,
    simulation_result: Optional[dict] = None,
) -> dict:
    route = request.get("route", {})
    start = route.get("start", {})
    end = route.get("end", {})
    intervention = request.get("intervention", {})
    options = request.get("options", {})

    demand_matrix = demand_data.get("demand_matrix", [])
    total_trips = sum(float(row.get("synthetic_trip_count", 0)) for row in demand_matrix)
    impact_report = phase34_output.get("impact_report") or {}
    feasibility = phase34_output.get("feasibility", {})
    smart = phase34_output.get("smart_recommendation") or {}
    artifacts = phase34_output.get("artifacts") or {}

    artifact_urls = {}
    for key, path in artifacts.items():
        if path:
            filename = path.rsplit("/", 1)[-1]
            artifact_urls[key] = f"/api/artifacts/{filename}"

    simulation = dict(simulation_result or {})
    time_reduction = float(simulation.get("time_reduction_pct", 0) or 0)
    congestion_reduction = float(simulation.get("congestion_reduction_pct", 0) or 0)

    widening_impact = phase2_result.get("widening_impact") or {}
    signal_impact = phase2_result.get("signal_optimization") or {}
    if widening_impact:
        congestion_reduction = min(
            65.0,
            congestion_reduction + float(widening_impact.get("estimated_congestion_reduction_pct", 0)),
        )
    if signal_impact:
        time_reduction = min(
            65.0,
            time_reduction + float(signal_impact.get("estimated_time_reduction_pct", 0)),
        )

    improvement_ratio = max(time_reduction, congestion_reduction) / 100.0
    simulation["hourly_traffic"] = _build_hourly_traffic(demand_data, improvement_ratio)
    simulation["time_reduction_pct"] = round(time_reduction, 1)
    simulation["congestion_reduction_pct"] = round(congestion_reduction, 1)

    cautions = []
    if not feasibility.get("is_feasible"):
        cautions.append(
            f"Building collisions detected ({feasibility.get('collision_count', 0)}). "
            "Route revision required before construction."
        )
    if smart.get("risk_factors"):
        cautions.extend(smart["risk_factors"])
    if phase2_result.get("status") == "heuristic_preview":
        cautions.append(phase2_result.get("note", "Phase 2 estimates applied."))

    return {
        "status": "success",
        "feasibility": feasibility,
        "impact": {
            "original_edges": impact_report.get("Original Network Edges"),
            "updated_edges": impact_report.get("Updated Network Edges"),
            "new_connections": impact_report.get("New Connections Spliced"),
        },
        "smart_recommendation": smart,
        "demand": {
            "scenario_metadata": demand_data.get("scenario_metadata", {}),
            "total_people_estimate": int(total_trips * 100),
            "top_corridors": demand_matrix,
        },
        "phase2": phase2_result,
        "simulation": simulation,
        "artifacts": artifact_urls,
        "report": {
            "reportName": f"Intervention: {start.get('name', 'Start')} - {end.get('name', 'End')}",
            "collaborators": ["UIDT System"],
            "fromPlace": start.get("name", "Unknown"),
            "toPlace": end.get("name", "Unknown"),
            "totalPeople": int(total_trips * 100),
            "solutions": {
                "type": intervention.get("type", "infrastructure"),
                "infraType": intervention.get("infra_type"),
                "widening": options.get("widening", False),
                "signal": options.get("smart_signals", False),
            },
            "adoptionRate": 75,
            "feasibility": feasibility,
            "impact": {
                "original_edges": impact_report.get("Original Network Edges"),
                "updated_edges": impact_report.get("Updated Network Edges"),
                "new_connections": impact_report.get("New Connections Spliced"),
            },
            "simulation": simulation,
            "smartRecommendation": smart,
            "hourlyTraffic": simulation.get("hourly_traffic", []),
            "metrics": {
                "trafficReduction": max(0, int(congestion_reduction)),
                "timeSaved": max(0, int(time_reduction)),
                "diversion": int(impact_report.get("New Connections Spliced", 0) or 0) * 5,
            },
            "cautions": cautions,
            "phase2": phase2_result,
            "routes": [
                {
                    "name": f"{row.get('sourcename', '?')} → {row.get('dstname', '?')}",
                    "people": int(float(row.get("synthetic_trip_count", 0)) * 100),
                    "distance": "—",
                    "time": f"{row.get('travel_time_min', '?')} min",
                }
                for row in demand_matrix[:5]
            ],
        },
        "pipeline_output": phase34_output,
    }
