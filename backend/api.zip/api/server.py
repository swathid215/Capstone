import sys
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

BACKEND_ROOT = Path(__file__).resolve().parents[1]
if str(BACKEND_ROOT) not in sys.path:
    sys.path.insert(0, str(BACKEND_ROOT))

load_dotenv(BACKEND_ROOT / ".env")

from paths import SHARED_DIR
from api.adapters import build_analyze_response, wizard_to_phase34_payload
from api.demand_service import get_or_generate_demand
from api.simulation_service import run_corridor_simulation, run_traffic_simulation

PHASE3_DIR = BACKEND_ROOT / "phases" / "phase3_infra" / "traffic-infra-engine"
PHASE2_DIR = BACKEND_ROOT / "phases" / "phase2_placeholder"
PHASE1_DIR = BACKEND_ROOT / "phases" / "phase1_demand"
for directory in (PHASE3_DIR, PHASE2_DIR, PHASE1_DIR):
    if str(directory) not in sys.path:
        sys.path.insert(0, str(directory))

from phase34_pipeline import Phase34Pipeline
from phase34_visualizer import Phase34Visualizer
from runner import run_phase2

app = FastAPI(title="UIDT API", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class Location(BaseModel):
    lat: float
    lon: float
    name: str = "Unknown"


class Route(BaseModel):
    start: Location
    end: Location


class InterventionGeometry(BaseModel):
    type: str = "LineString"
    coordinates: list[list[float]] = Field(default_factory=list)


class Intervention(BaseModel):
    type: str = "infrastructure"
    infra_type: str = "flyover"
    geometry: InterventionGeometry = Field(default_factory=InterventionGeometry)
    road_width_m: float = 8
    is_oneway: bool = False


class Scenario(BaseModel):
    target_hour: int = 9
    ward_no: int = 163
    place_name: str = "Kathriguppe, Bangalore, India"
    dist_m: int = 5000
    congestion_multiplier: float = 1.0


class AnalyzeOptions(BaseModel):
    widening: bool = False
    smart_signals: bool = False
    smart_analysis: bool = True


class AnalyzeRequest(BaseModel):
    route: Route
    intervention: Intervention = Field(default_factory=Intervention)
    scenario: Scenario = Field(default_factory=Scenario)
    options: AnalyzeOptions = Field(default_factory=AnalyzeOptions)
    report_name: Optional[str] = None
    simulation_result: Optional[dict] = None


class CorridorSimulationRequest(BaseModel):
    origin: Location
    destination: Location
    target_hour: int = Field(default=9, ge=0, le=23)
    ward_no: int = Field(default=163, ge=1)
    congestion_multiplier: float = Field(default=1.0, gt=0)


@app.get("/health")
def health():
    return {"status": "ok", "service": "uidt-api"}


@app.get("/demand")
def demand(
    hour: int = Query(9, ge=0, le=23),
    ward_no: int = Query(163, ge=1),
    multiplier: float = Query(1.0, gt=0),
    refresh: bool = Query(False),
):
    try:
        data = get_or_generate_demand(
            target_hour=hour,
            ward_no=ward_no,
            congestion_multiplier=multiplier,
            refresh=refresh,
        )
        return {"status": "success", "data": data}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@app.post("/simulate")
def simulate(request: CorridorSimulationRequest):
    try:
        demand_data = get_or_generate_demand(
            target_hour=request.target_hour,
            ward_no=request.ward_no,
            congestion_multiplier=request.congestion_multiplier,
        )
        return run_corridor_simulation(
            request.origin.model_dump(), request.destination.model_dump(), demand_data
        )
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@app.post("/analyze")
def analyze(request: AnalyzeRequest):
    try:
        payload = request.model_dump()
        phase34_payload = wizard_to_phase34_payload(payload)

        if len(phase34_payload["proposal"]["coordinates"]) < 2:
            raise HTTPException(
                status_code=400,
                detail="At least two route coordinates are required.",
            )

        demand_data = get_or_generate_demand(
            target_hour=request.scenario.target_hour,
            ward_no=request.scenario.ward_no,
            congestion_multiplier=request.scenario.congestion_multiplier,
        )

        pipeline = Phase34Pipeline()
        phase34_output = pipeline.run_from_dict(phase34_payload)

        simulation_result = request.simulation_result or run_corridor_simulation(
            request.route.start.model_dump(),
            request.route.end.model_dump(),
            demand_data,
        )

        phase2_result = run_phase2(
            request=payload,
            graph=pipeline.modified_graph or pipeline.original_graph,
            feasibility_result=phase34_output.get("feasibility"),
        )

        response = build_analyze_response(
            payload, phase34_output, demand_data, phase2_result, simulation_result
        )

        try:
            Phase34Visualizer().generate_map()
            response["artifacts"]["map_html"] = "/api/artifacts/phase34_map.html"
            response["report"]["artifacts"] = response["artifacts"]
        except Exception as exc:
            print(f"[API] Map visualization skipped: {exc}")

        try:
            from tanisha_visualizer import generate_map as generate_demand_map
            generate_demand_map()
            response["artifacts"]["demand_map_html"] = "/api/artifacts/traffic_map.html"
        except Exception as exc:
            print(f"[API] Demand map skipped: {exc}")

        return response
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@app.get("/artifacts/{filename}")
def get_artifact(filename: str):
    safe_name = Path(filename).name
    file_path = SHARED_DIR / safe_name
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="Artifact not found")
    return FileResponse(file_path)


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("api.server:app", host="127.0.0.1", port=8000, reload=True)
