import json
import sys
from pathlib import Path

from paths import SHARED_DIR

PHASE1_DIR = Path(__file__).resolve().parents[1] / "phases" / "phase1_demand"
if str(PHASE1_DIR) not in sys.path:
    sys.path.insert(0, str(PHASE1_DIR))

from tanisha_pipeline import TanishaTrafficPipeline

DEMAND_FILE = SHARED_DIR / "integration_demand.json"
CSV_FILE = PHASE1_DIR / "bangalore-wards-2019-3-OnlyWeekdays-HourlyAggregate.csv"


def _matches_cached(meta: dict, target_hour: int, ward_no: int, multiplier: float) -> bool:
    return (
        meta.get("target_hour") == target_hour
        and meta.get("ward_no") == ward_no
        and float(meta.get("multiplier", 1.0)) == float(multiplier)
    )


def get_or_generate_demand(
    target_hour: int = 9,
    ward_no: int = 163,
    congestion_multiplier: float = 1.0,
    refresh: bool = False,
) -> dict:
    if not refresh and DEMAND_FILE.exists():
        with open(DEMAND_FILE, "r", encoding="utf-8") as file:
            cached = json.load(file)
        meta = cached.get("scenario_metadata", {})
        if _matches_cached(meta, target_hour, ward_no, congestion_multiplier):
            return cached

    pipeline = TanishaTrafficPipeline(str(CSV_FILE))
    output_path = pipeline.generate_demand(
        congestion_multiplier=congestion_multiplier,
        target_hour=target_hour,
        ward_no=ward_no,
    )
    if not output_path:
        raise RuntimeError(f"Demand generation failed for ward {ward_no} at hour {target_hour}")

    with open(output_path, "r", encoding="utf-8") as file:
        return json.load(file)
